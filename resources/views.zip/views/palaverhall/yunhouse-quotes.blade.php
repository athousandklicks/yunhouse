@extends('palaver-main')

@section('title', '| Quote of the week')


@section('stylesheet')
    {!! Html::style('/css/style.css') !!}
@endsection



@section('content')


@endsection