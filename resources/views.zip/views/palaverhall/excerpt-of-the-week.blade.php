@extends('palaver-main')

@section('title', '| Excerpt of the Week')


@section('stylesheet')
    {!! Html::style('/css/style.css') !!}
@endsection



@section('content')


@endsection