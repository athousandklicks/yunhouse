                    <div class="panel panel-default sidebar-menu">

                    	<div class="panel-heading">
                    		<h3 class="panel-title">Yunhouse Characters</h3>
                    	</div>

                    	<div class="panel-body">
                    		<ul class="nav nav-pills nav-stacked category-menu">
                            <li class="{{ Request::is('cy') ? "active" : "" }}">
                                    <a href="/cy">Cyril Naikule</a>
                                </li>
                                <li class="{{ Request::is('lekwot') ? "active" : "" }}">
                                    <a href="/lekwot">Lekwot Abaka</a>
                                </li>
                                <li class="{{ Request::is('ogesayi') ? "active" : "" }}">
                                    <a href="/ogesayi">Ogesayi Mawe</a>
                                </li>
                    			<li class="{{ Request::is('mnama') ? "active" : "" }}">
                    				<a href="/mnama">Big Mnama</a>
                    			</li>
                    			<li class="{{ Request::is('africa-picture') ? "active" : "" }}">
                    				<a href="/africa-picture">The Africa Picture (No Spitting)</a>
                    			</li>
                    			<li class="{{ Request::is('afrinc') ? "active" : "" }}">
                    				<a href="/afrinc">Afrinc</a>
                    			</li>

                                <li class="{{ Request::is('gafla') ? "active" : "" }}">
                                    <a href="/gafla">John O'Gafla</a>
                                </li>

                                <li class="{{ Request::is('african-adventurers') ? "active" : "" }}">
                                    <a href="/african-adventurers">The African Adventurers Club</a>
                                </li>

                                <li class="{{ Request::is('africa-freedom') ? "active" : "" }}">
                                    <a href="/africa-freedom">The Africa Freedom Council</a>
                                </li>

                                <li class="{{ Request::is('nkungolo') ? "active" : "" }}">
                                    <a href="/nkungolo">Sir Emmanuel Nkungolo</a>
                                </li>

                                <li class="{{ Request::is('alphonsus') ? "active" : "" }}">
                                    <a href="/alphonsus">Professor Alphonsus Do-Remi</a>
                                </li>

                                <li class="{{ Request::is('beryl-fairbanks') ? "active" : "" }}">
                                    <a href="/beryl-fairbanks">Beryl Fairbanks</a>
                                </li>

                                <li class="{{ Request::is('berliner-cult') ? "active" : "" }}">
                                    <a href="/berliner-cult">The Berliner Cult (a.k.a The Core-23)</a>
                                </li>

                                <li class="{{ Request::is('palavar') ? "active" : "" }}">
                                    <a href="/palavar">Palavar Hall</a>
                                </li>

                    		</ul>

                    	</div>
                    </div>