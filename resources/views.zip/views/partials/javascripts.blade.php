    <!--/#scripts--> 
    <script type="text/javascript" src="/js/jquery.js"></script>
    <script type="text/javascript" src="/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="/js/owl.carousel.min.js"></script> 
    <script type="text/javascript" src="/js/moment.min.js"></script> 
    <script type="text/javascript" src="/js/jquery.simpleWeather.min.js"></script> 
    <script type="text/javascript" src="/js/jquery.sticky-kit.min.js"></script>
    <script type="text/javascript" src="/js/jquery.easy-ticker.min.js"></script> 
    <script type="text/javascript" src="/js/jquery.subscribe-better.min.js"></script> 
    <script type="text/javascript" src="/js/main.js"></script>
    <script type="text/javascript" src="/js/switcher.js"></script>