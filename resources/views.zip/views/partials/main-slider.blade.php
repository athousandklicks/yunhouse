                    <div id="main-slider">
                        <div class="item">
                            <img src="/images/slides/main-slider1.png" alt="" class="img-responsive">
                        </div>
                        <div class="item">
                            <img class="img-responsive" src="/images/slides/main-slider1.png" alt="">
                        </div>
                        <div class="item">
                            <img class="img-responsive" src="/images/slides/main-slider1.png" alt="">
                        </div>
                        <div class="item">
                            <img class="img-responsive" src="/images/slides/main-slider1.png" alt="">
                        </div>
                    </div>
                    <!-- /#main-slider -->