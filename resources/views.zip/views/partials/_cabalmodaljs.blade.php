  function ConfirmDelete()
  {
  var x = confirm("Are you sure you want to delete?");
  if (x)
    return true;
  else
    return false;
  }


    function ConfirmSave()
  {
  var x = confirm("Are you sure you want to save changes?");
  if (x)
    return true;
  else
    return false;
  }