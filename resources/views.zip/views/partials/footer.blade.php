    <footer id="footer">
      <div class="footer-top">
        <div class="container text-center">
          <div class="logo-icon"><a href="https://www.amazon.co.uk/dp/1999864107?ref_=pe_870760_150889320?_encoding=UTF8&camp=1789&creative=9325&linkCode=ur2&tag=storypodca-20&linkId=2P4S6EY6B462X4AR" target="_blank"><img class="img-responsive" src="/images/frontend/amazon-button.png" alt="" /></a></div>
        </div>
      </div>
      <div class="footer-menu">
        <div class="container">
          <ul class="nav navbar-nav">                       
            <li><a href="/yunhouse-in-brief">THE YUNHOUSE STORY</a></li>
            <li><a href="/about-author">ABOUT THE AUTHOR</a></li>
            <li><a href="/yunhouse-character">YUNHOUSE CHARACTERS</a></li>
            <li><a href="/list-of-tales">INTRO TALES</a></li>
            {{-- <li><a href="/1884-gallery">1884 GALLERY</a></li> --}}
            <li><a href="/debate-index">PALAVER HALL</a></li>
            <li><a href="/list-of-reviews">REVIEWS</a></li>
          </ul> 
        </div>
      </div>

      <div class="footer-bottom">
        <div class="container text-center">
          <p><a href="/">Yunhouse </a>&copy;2018 </p>
        </div>
      </div>    
    </footer>