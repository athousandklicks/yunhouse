    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--title-->
    <title> YUNHOUSE: @yield('title')</title>
    
    <!--CSS-->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/font-awesome.min.css" rel="stylesheet">
    <link href="/css/magnific-popup.css" rel="stylesheet">
    <link href="/css/owl.carousel.css" rel="stylesheet">
    <link href="/css/subscribe-better.css" rel="stylesheet">
    <link href="/css/main.css" rel="stylesheet">
    <link id="preset" rel="stylesheet" type="text/css" href="/css/presets/preset1.css">
    <link href="/css/responsive.css" rel="stylesheet">       
    
    <!--Google Fonts-->
    <link href='https://fonts.googleapis.com/css?family=Signika+Negative:400,300,600,700' rel='stylesheet' type='text/css'>
    
    <!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
    <![endif]-->    

    <link rel="shortcut icon" href="images/ico/favicon.ico">   

