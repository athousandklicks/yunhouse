			<div id="breaking-news">
				<span>Breaking News</span>
				<div class="breaking-news-scroll">
					<ul>
						<li><i class="fa fa-angle-double-right"></i>
							<a href="?page=post" title="">We are seeing the effects of the minimum wage rise</a>
						</li>
						<li><i class="fa fa-angle-double-right"></i>
							<a href="?page=post" title="">YouTube star PewDiePie responds to commenters angry</a>
						</li>
						<li><i class="fa fa-angle-double-right"></i>
							<a href="?page=post" title="">Ut enim ad minim veniam, quis nostrud</a>
						</li>
					</ul>
				</div>
				</div>
			