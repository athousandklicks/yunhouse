<div class="copyrights">
	 <p>© 2017 YUNHOUSE - Assorted London Tales About the Africa | Design by  <a href="http://bagus.com.ng" target="_blank">Bagus Integrated</a> </p>
</div>	

<!--COPY rights end here-->

</div>  <!--<div class="left-content"> ends here-->
</div> <!--<div class="mother-grid-inner"> ends here-->