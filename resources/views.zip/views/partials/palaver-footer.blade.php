    <footer id="footer">
      <div class="footer-top">
        <div class="container text-center">
          <div class="logo-icon"><a href="https://www.amazon.co.uk/dp/1999864107?ref_=pe_870760_150889320?_encoding=UTF8&camp=1789&creative=9325&linkCode=ur2&tag=storypodca-20&linkId=2P4S6EY6B462X4AR" target="_blank"><img class="img-responsive" src="/images/frontend/amazon-button.png" alt="" /></a></div>
        </div>
      </div>
      <div class="footer-menu">
        <div class="container">
          <ul class="nav navbar-nav">                       
            <li><a href="/debate-index">CURRENT DEBATE</a></li>
            <li><a href="/list-of-debates">1884 DEBATES</a></li>
            <li><a href="/1884-gallery">1884 GALLERY</a></li>
            <li><a href="/palaver-quotes">QUOTES</a></li>
            <li><a href="/list-of-tales">YUNTALES</a></li>
            <li><a href="/">VISIT YUNHOUSE</a></li>
          </ul> 
        </div>
      </div>

      <div class="footer-bottom">
        <div class="container text-center">
          <p><a href="/">Yunhouse </a>&copy;2018 </p>
        </div>
      </div>    
    </footer>